* Title: Specman Elite Tutorial
* Name: sn_tutorial
* Version: 8.1
* Modified: May, 2008
* Category: Tutorial 
* Documentation: docs/sn_8.1_tutorial.pdf
* Description:

The goal of this tutorial is to give you first-hand 
experience in how the Specman Elite system effectively 
addresses functional verification challenges.

This tutorial uses the Specman Elite system to create a 
verification environment for a simple CPU design.

* Directory structure:

This package contains the following directories:
 
  e/         - all e sources
  
       /gold - subdirectory for original code with the solutions 
  
       /src  - subdirectory for initial code to work on throughout 
	           the tutorial	
  
  docs/      - all documents

